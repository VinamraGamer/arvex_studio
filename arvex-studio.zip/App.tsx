
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import AIConsultant from './components/AIConsultant';
import Contact from './components/Contact';
import Footer from './components/Footer';
import CaseStudyPage from './components/CaseStudyPage';
import AdminDashboard from './components/AdminDashboard';
import AdminLogin from './components/AdminLogin';
import ClientAuthWall from './components/ClientAuthWall';
import ProfileSettings from './components/ProfileSettings';
import { CaseStudy, UserProfile } from './types';
import { scrollToSection } from './utils/navigation';

const GUEST_PFP = 'https://cdn-icons-png.flaticon.com/512/149/149071.png';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<'home' | 'case-study' | 'admin-login' | 'admin-dashboard'>('home');
  const [activeCaseStudy, setActiveCaseStudy] = useState<CaseStudy | null>(null);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [isClientAuthenticated, setIsClientAuthenticated] = useState(false);
  const [interactionCount, setInteractionCount] = useState(0);
  const [isManualAuthOpen, setIsManualAuthOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);

  useEffect(() => {
    const clientAuth = localStorage.getItem('arvex_client_auth') === 'true';
    setIsClientAuthenticated(clientAuth);

    const savedProfile = localStorage.getItem('arvex_user_profile');
    if (savedProfile) {
      setUserProfile(JSON.parse(savedProfile));
    } else {
      const defaultProfile: UserProfile = {
        name: 'Guest User',
        email: '',
        phone: '',
        bio: '',
        pfp: GUEST_PFP
      };
      setUserProfile(defaultProfile);
      localStorage.setItem('arvex_user_profile', JSON.stringify(defaultProfile));
    }

    const savedTheme = localStorage.getItem('arvex_theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (savedTheme === 'dark' || (!savedTheme && prefersDark)) {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleTheme = () => {
    setIsDarkMode(prev => {
      const newVal = !prev;
      if (newVal) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('arvex_theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('arvex_theme', 'light');
      }
      return newVal;
    });
  };

  const incrementInteraction = () => {
    if (isClientAuthenticated) return;
    setInteractionCount(prev => prev + 1);
  };

  const handleOpenCaseStudy = (cs: CaseStudy) => {
    incrementInteraction();
    setActiveCaseStudy(cs);
    setCurrentView('case-study');
    window.scrollTo(0, 0);
  };

  const handleBackToHome = () => {
    setCurrentView('home');
    setActiveCaseStudy(null);
  };

  const handleRequestAnalysis = () => {
    incrementInteraction();
    setCurrentView('home');
    setActiveCaseStudy(null);
    setTimeout(() => {
      scrollToSection('contact');
    }, 100);
  };

  const handleOpenAdmin = () => {
    if (isAdminAuthenticated) {
      setCurrentView('admin-dashboard');
    } else {
      setCurrentView('admin-login');
    }
  };

  const handleAdminLoginSuccess = () => {
    setIsAdminAuthenticated(true);
    setCurrentView('admin-dashboard');
  };

  const handleClientAuthenticated = (userData: { name: string; email: string; password?: string; authMethod?: string; pfp?: string }) => {
    setIsClientAuthenticated(true);
    setIsManualAuthOpen(false);
    setInteractionCount(0);
    
    // Recover previous data for this specific email from the vault
    const vaultStr = localStorage.getItem('arvex_partner_vault') || '{}';
    const vault = JSON.parse(vaultStr);
    const existingEntry = vault[userData.email];

    // Create the updated profile based on current input and vault history
    const updatedProfile: UserProfile = {
      name: userData.name || existingEntry?.name || 'Partner',
      email: userData.email,
      phone: existingEntry?.phone || '',
      bio: existingEntry?.bio || '',
      pfp: userData.pfp || existingEntry?.pfp || GUEST_PFP,
      password: userData.password || existingEntry?.password || ''
    };

    setUserProfile(updatedProfile);
    localStorage.setItem('arvex_user_profile', JSON.stringify(updatedProfile));
    localStorage.setItem('arvex_client_auth', 'true');
    
    // Update the vault to ensure persistent recovery
    vault[userData.email] = updatedProfile;
    localStorage.setItem('arvex_partner_vault', JSON.stringify(vault));
  };

  const handleSaveProfile = (updated: UserProfile) => {
    setUserProfile({ ...updated });
    localStorage.setItem('arvex_user_profile', JSON.stringify(updated));
    
    if (updated.email) {
      const vaultStr = localStorage.getItem('arvex_partner_vault') || '{}';
      const vault = JSON.parse(vaultStr);
      vault[updated.email] = updated;
      localStorage.setItem('arvex_partner_vault', JSON.stringify(vault));
    }
  };

  const handleLogout = () => {
    setIsClientAuthenticated(false);
    setIsProfileOpen(false);
    setIsManualAuthOpen(false);
    setInteractionCount(0);
    
    localStorage.removeItem('arvex_client_auth');
    
    const guest: UserProfile = {
      name: 'Guest User',
      email: '',
      phone: '',
      bio: '',
      pfp: GUEST_PFP
    };
    setUserProfile(guest);
    localStorage.setItem('arvex_user_profile', JSON.stringify(guest));
  };

  const handleOpenAuth = () => {
    setIsManualAuthOpen(true);
  };

  const handleCloseAuth = () => {
    setIsManualAuthOpen(false);
  };

  const handleNavbarProfileClick = () => {
    if (isClientAuthenticated) {
      setIsProfileOpen(true);
    } else {
      setIsManualAuthOpen(true);
    }
  };

  const showAuthWall = (!isClientAuthenticated && interactionCount >= 3) || isManualAuthOpen;

  if (currentView === 'admin-login') {
    return <AdminLogin onLoginSuccess={handleAdminLoginSuccess} onBack={handleBackToHome} />;
  }

  if (currentView === 'admin-dashboard') {
    return <AdminDashboard onBack={handleBackToHome} />;
  }

  if (currentView === 'case-study' && activeCaseStudy) {
    return (
      <CaseStudyPage 
        caseStudy={activeCaseStudy} 
        onBack={handleBackToHome} 
        onRequestAnalysis={handleRequestAnalysis}
      />
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 bg-white dark:bg-slate-950 selection:bg-blue-100 dark:selection:bg-blue-500/20 selection:text-blue-900 dark:selection:text-blue-200 overflow-x-hidden ${showAuthWall || isProfileOpen ? 'h-screen overflow-hidden' : ''}`}>
      {showAuthWall && (
        <ClientAuthWall 
          onAuthenticated={handleClientAuthenticated} 
          onClose={isManualAuthOpen ? handleCloseAuth : undefined} 
        />
      )}

      {isProfileOpen && userProfile && (
        <ProfileSettings 
          profile={userProfile} 
          isClientAuthenticated={isClientAuthenticated}
          onSave={handleSaveProfile} 
          onLogout={handleLogout}
          onClose={() => setIsProfileOpen(false)} 
        />
      )}
      
      <Navbar 
        onInteract={incrementInteraction} 
        onOpenAuth={handleOpenAuth} 
        onOpenProfile={handleNavbarProfileClick}
        isClientAuthenticated={isClientAuthenticated} 
        userProfile={userProfile}
        isDarkMode={isDarkMode}
        toggleTheme={toggleTheme}
      />
      <main>
        <Hero onInteract={incrementInteraction} />
        <About />
        <Services onOpenCaseStudy={handleOpenCaseStudy} />
        
        <section className="py-32 bg-white dark:bg-slate-950 overflow-hidden relative border-y border-slate-100 dark:border-white/5">
          <div className="max-w-7xl mx-auto px-6">
            <div className="bg-slate-900 dark:bg-slate-900/50 border border-transparent dark:border-white/5 rounded-[60px] p-12 md:p-24 text-white text-center relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/20 rounded-full blur-[100px] group-hover:scale-150 transition-transform duration-700"></div>
               <div className="relative z-10">
                 <h2 className="text-4xl md:text-6xl font-serif italic mb-8">Ready to <span className="text-blue-400 not-italic font-sans font-black">Co-Author</span> <br />Your Next Success Story?</h2>
                 <p className="text-slate-400 dark:text-slate-500 max-w-xl mx-auto mb-12 text-lg">
                   Our portfolio is built on the ambitious goals of our partners. Click below to initiate a strategic consultation and start your own case study.
                 </p>
                 <button 
                   onClick={handleRequestAnalysis}
                   className="bg-white text-slate-900 px-12 py-6 rounded-2xl text-xs font-black uppercase tracking-[0.2em] hover:bg-blue-400 hover:text-white transition-all active:scale-95 shadow-2xl shadow-white/5"
                 >
                   Add Your Case Study
                 </button>
               </div>
            </div>
          </div>
        </section>

        <AIConsultant onInteract={incrementInteraction} />
        <Contact userProfile={userProfile} isClientAuthenticated={isClientAuthenticated} />
      </main>
      
      <Footer onOpenAdmin={handleOpenAdmin} isDarkMode={isDarkMode} />
    </div>
  );
};

export default App;
