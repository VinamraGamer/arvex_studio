
export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface Stat {
  label: string;
  value: string;
  description: string;
}

export interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export interface CaseStudyMetric {
  label: string;
  value: string;
}

export interface CaseStudy {
  id: number;
  title: string;
  client: string;
  challenge: string;
  solution: string;
  result: string;
  metrics: CaseStudyMetric[];
  themeColor: string;
  industryIcon: string;
  heroImage: string;
}

export interface Inquiry {
  id: string;
  name: string;
  email: string;
  message: string;
  timestamp: number;
  status: 'new' | 'contacted' | 'completed';
}

export interface UserProfile {
  name: string;
  email: string;
  phone: string;
  bio: string;
  pfp: string;
  password?: string;
}