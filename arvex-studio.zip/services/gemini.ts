
import { GoogleGenAI } from "@google/genai";

export const getAIRecommendation = async (userProblem: string) => {
  // Creating instance immediately before call to ensure fresh API key context
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [{ 
        parts: [{ 
          text: `Provide a high-level technical roadmap for building a custom, from-scratch web/software solution for: "${userProblem}". 
          The roadmap should focus on:
          1. Recommended Modern Tech Stack (Fast & Secure)
          2. Core "Build from Scratch" Strategy (Avoid templates/bloat)
          3. Affordable Scaling & Cost Optimization
          
          Maintain the Arvex Studio voice: technical, focused on ROI, and authoritative about custom engineering. Use markdown formatting.`
        }] 
      }],
      config: {
        systemInstruction: "You are the Head of Engineering at Arvex Studio. You specialize in building high-performance websites and apps from scratch. Your goal is to convince the client that custom builds are faster, more secure, and more affordable in the long run than templates. Be concise and technical.",
        temperature: 0.7,
        topP: 0.9,
      },
    });

    if (!response || !response.text) {
      throw new Error("No content received from intelligence engine.");
    }

    return response.text;
  } catch (error) {
    console.error("AI Generation Error:", error);
    throw error;
  }
};
