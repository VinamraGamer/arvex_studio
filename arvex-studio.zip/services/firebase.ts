
import { initializeApp, getApp, getApps } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

/**
 * 🛠️ FIREBASE AUTHENTICATION CONFIGURATION
 * 1. Visit https://console.firebase.google.com/
 * 2. Create a project and add a Web App.
 * 3. Copy your config keys here.
 * 4. Enable Google Login in the 'Authentication' tab.
 * 5. Add your domain to 'Authorized Domains' when launching.
 */
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// Initialize Firebase safely (Singleton Pattern)
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Export Auth Services
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Custom Parameters to force account selection
googleProvider.setCustomParameters({
  prompt: 'select_account'
});
