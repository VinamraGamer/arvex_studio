
import React, { useState, useEffect } from 'react';
import { scrollToSection } from '../utils/navigation';
import Logo from './Logo';
import { UserProfile } from '../types';

interface NavbarProps {
  onInteract: () => void;
  onOpenAuth: () => void;
  onOpenProfile: () => void;
  isClientAuthenticated: boolean;
  userProfile: UserProfile | null;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ 
  onInteract, 
  onOpenAuth, 
  onOpenProfile, 
  isClientAuthenticated, 
  userProfile, 
  isDarkMode, 
  toggleTheme 
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Approach', id: 'about' },
    { name: 'Solutions', id: 'services' },
    { name: 'Intelligence', id: 'ai-consultant' },
  ];

  const handleMobileClick = (id: string) => {
    setIsMenuOpen(false);
    onInteract();
    scrollToSection(id);
  };

  const handleCta = () => {
    onInteract();
    scrollToSection('contact');
  };

  return (
    <>
      <nav className="fixed top-0 w-full z-50 px-4 md:px-8 py-4 md:py-6 transition-all duration-300">
        <div className={`max-w-7xl mx-auto flex items-center justify-between px-6 md:px-8 py-3 md:py-4 rounded-2xl transition-all duration-500 ${isScrolled || isMenuOpen ? 'glass shadow-lg border-slate-200/50 dark:border-white/5' : 'bg-transparent border-transparent'}`}>
          <div className="z-50 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            <Logo light={isDarkMode} />
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <button
                key={link.name}
                type="button"
                onClick={() => { onInteract(); scrollToSection(link.id); }}
                className="text-[10px] uppercase tracking-widest font-black text-slate-500 dark:text-slate-400 hover:text-blue-600 transition-colors focus:outline-none"
              >
                {link.name}
              </button>
            ))}
            
            <div className="h-6 w-px bg-slate-200 dark:bg-slate-800"></div>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-xl bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-blue-600 transition-all border border-transparent dark:border-white/5"
              aria-label="Toggle Theme"
            >
              {isDarkMode ? (
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707M16.95 16.95l.707.707M7.05 7.05l.707-.707M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              ) : (
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                </svg>
              )}
            </button>

            {/* Always visible profile trigger */}
            <button
              onClick={onOpenProfile}
              className="flex items-center space-x-3 group bg-slate-100 dark:bg-slate-900 px-3 py-1.5 rounded-xl border border-transparent dark:border-white/5 hover:border-blue-500/30 transition-all"
              title={isClientAuthenticated ? "View Profile Settings" : "Login to modify profile"}
            >
              <div className={`w-7 h-7 rounded-lg overflow-hidden border border-white dark:border-slate-800 ${!isClientAuthenticated ? 'opacity-50 grayscale' : ''}`}>
                <img 
                  src={userProfile?.pfp || 'https://cdn-icons-png.flaticon.com/512/149/149071.png'} 
                  alt="Profile" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex flex-col items-start leading-none text-left">
                <span className="text-[9px] font-black uppercase tracking-tighter text-slate-900 dark:text-white mb-0.5">
                  {userProfile?.name?.split(' ')[0] || (isClientAuthenticated ? 'Partner' : 'Guest')}
                </span>
                <span className={`text-[7px] font-bold uppercase tracking-widest flex items-center ${isClientAuthenticated ? 'text-emerald-500' : 'text-slate-400'}`}>
                  <span className={`w-1 h-1 rounded-full mr-1 ${isClientAuthenticated ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`}></span> 
                  {isClientAuthenticated ? 'Active' : 'Guest'}
                </span>
              </div>
            </button>

            {!isClientAuthenticated && (
              <button
                type="button"
                onClick={onOpenAuth}
                className="text-[10px] uppercase tracking-[0.2em] font-black text-slate-900 dark:text-slate-100 hover:text-blue-600 transition-colors focus:outline-none"
              >
                Login
              </button>
            )}

            <button
              type="button"
              onClick={handleCta}
              className="bg-slate-900 dark:bg-blue-600 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-600 dark:hover:bg-blue-500 transition-all shadow-xl shadow-slate-900/10 active:scale-95 focus:outline-none"
            >
              Get in Touch
            </button>
          </div>

          {/* Mobile Actions */}
          <div className="md:hidden flex items-center space-x-2 z-50">
            <button
              onClick={toggleTheme}
              className="p-2.5 bg-slate-100 dark:bg-slate-900 rounded-xl text-slate-600 dark:text-slate-400"
            >
              {isDarkMode ? (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707M16.95 16.95l.707.707M7.05 7.05l.707-.707M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              ) : (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
              )}
            </button>

            <button
              onClick={onOpenProfile}
              className="w-10 h-10 flex items-center justify-center bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-white/5 shadow-sm overflow-hidden"
            >
                <img 
                  src={userProfile?.pfp || 'https://cdn-icons-png.flaticon.com/512/149/149071.png'} 
                  alt="Profile" 
                  className={`w-7 h-7 rounded-lg object-cover ${!isClientAuthenticated ? 'grayscale opacity-50' : ''}`}
                />
            </button>

            <button 
              type="button" 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-slate-900 dark:text-white focus:outline-none p-2.5 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-white/5"
            >
              <div className="w-5 h-4 relative flex flex-col justify-between">
                <span className={`w-full h-0.5 bg-current transition-all ${isMenuOpen ? 'rotate-45 translate-y-1.5' : ''}`}></span>
                <span className={`w-full h-0.5 bg-current transition-all ${isMenuOpen ? 'opacity-0' : ''}`}></span>
                <span className={`w-full h-0.5 bg-current transition-all ${isMenuOpen ? '-rotate-45 -translate-y-2' : ''}`}></span>
              </div>
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      <div className={`fixed inset-0 z-40 bg-white dark:bg-slate-950 transition-transform duration-500 md:hidden ${isMenuOpen ? 'translate-y-0' : '-translate-y-full'}`}>
        <div className="flex flex-col items-center justify-center h-full space-y-8 px-6 text-center">
          <div className="text-[10px] uppercase tracking-[0.5em] font-black text-slate-300 dark:text-slate-700 mb-4">Navigational Hub</div>
          {navLinks.map((link) => (
            <button
              key={link.name}
              onClick={() => handleMobileClick(link.id)}
              className="text-3xl font-serif italic text-slate-900 dark:text-white hover:text-blue-600 transition-colors"
            >
              {link.name}
            </button>
          ))}
          <div className="w-12 h-px bg-slate-100 dark:bg-slate-800 my-4"></div>
          <button
            onClick={() => { setIsMenuOpen(false); handleCta(); }}
            className="w-full max-w-xs bg-slate-900 dark:bg-blue-600 text-white py-5 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] shadow-xl"
          >
            Initiate Contact
          </button>
        </div>
      </div>
    </>
  );
};

export default Navbar;
