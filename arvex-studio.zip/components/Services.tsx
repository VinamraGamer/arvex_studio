
import React from 'react';
import { CaseStudy } from '../types';

interface ServicesProps {
  onOpenCaseStudy: (cs: CaseStudy) => void;
}

const Services: React.FC<ServicesProps> = ({ onOpenCaseStudy }) => {
  const services = [
    { 
      title: 'Custom Web Development', 
      desc: 'High-performance websites built from scratch. No bulky CMS, no slow templates. Just lightning-fast React and Next.js code tailored to your brand.', 
      icon: 'M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4',
      caseStudy: {
        id: 1,
        title: 'Bespoke Retail Engine',
        client: 'Vanguard Boutique',
        themeColor: 'blue',
        industryIcon: 'code',
        heroImage: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=2000',
        challenge: 'A luxury boutique was losing sales due to a slow Shopify template that looked identical to their competitors.',
        solution: 'We built a 100% custom headless commerce site, giving them total design freedom and a 300% speed improvement over their old site.',
        result: 'Conversion rates doubled in the first month. The brand now owns its unique digital identity without recurring platform bloat.',
        metrics: [
          { label: 'Speed', value: '+300%' },
          { label: 'Conversion', value: '2.1x' },
          { label: 'Uniqueness', value: '100%' }
        ]
      }
    },
    { 
      title: 'Full-Stack Software', 
      desc: 'Scalable applications built for your specific workflow. We design the database, API, and UI from the ground up to solve your unique problems.', 
      icon: 'M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z',
      caseStudy: {
        id: 2,
        title: 'Custom Workflow Core',
        client: 'Atlas Logistics',
        themeColor: 'indigo',
        industryIcon: 'cpu',
        heroImage: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=2000',
        challenge: 'Atlas was juggling five different SaaS tools, leading to massive data entry errors and high monthly subscription costs.',
        solution: 'We engineered a single custom portal that unified their operations. Built from scratch to exactly match their physical logistics chain.',
        result: 'Saved $8k/month in subscription fees and reduced data entry time by 40%. The system paid for itself in under 6 months.',
        metrics: [
          { label: 'Monthly Savings', value: '$8k+' },
          { label: 'Time Saved', value: '40%' },
          { label: 'Payback', value: '<6 Months' }
        ]
      }
    },
    { 
      title: 'App Modernization', 
      desc: 'Old site holding you back? We strip away the legacy bloat and rebuild your existing product into a modern, fast, and secure digital asset.', 
      icon: 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15',
      caseStudy: {
        id: 4,
        title: 'The Clean Code Rebirth',
        client: 'Legacy Finance Corp',
        themeColor: 'rose',
        industryIcon: 'refresh',
        heroImage: 'https://images.unsplash.com/photo-1551288049-bbbda5366392?auto=format&fit=crop&q=80&w=2000',
        challenge: 'A financial firm had a 10-year-old codebase that was insecure and impossible to update, costing them new client trust.',
        solution: 'We modernised their core tech stack using TypeScript and Next.js, maintaining their existing data while building a fresh, secure frontend.',
        result: 'Zero security vulnerabilities. Client onboarding time dropped by 50% due to the new, streamlined UX.',
        metrics: [
          { label: 'Security', value: 'A+ Grade' },
          { label: 'Onboarding', value: '-50%' },
          { label: 'Lines Refactored', value: '1.2M' }
        ]
      }
    },
    { 
      title: 'AI Product Engineering', 
      desc: 'Integrate the power of LLMs into your custom apps. We build unique AI features that give your business a competitive edge.', 
      icon: 'M13 10V3L4 14h7v7l9-11h-7z',
      caseStudy: {
        id: 3,
        title: 'Intelligent Data Analyst',
        client: 'Propel Growth AI',
        themeColor: 'emerald',
        industryIcon: 'sparkles',
        heroImage: 'https://images.unsplash.com/photo-1518186285589-2f7649de83e0?auto=format&fit=crop&q=80&w=2000',
        challenge: 'Propel had mountains of data but no easy way for non-technical staff to query it for insights.',
        solution: 'We built a custom AI natural language interface that allows staff to "talk" to their database and generate reports instantly.',
        result: 'Reduced internal report requests to the dev team by 90%. Real-time decision making is now standard.',
        metrics: [
          { label: 'Dev Time Saved', value: '20hrs/wk' },
          { label: 'Adoption', value: '100%' },
          { label: 'Query Speed', value: '<2s' }
        ]
      }
    },
  ];

  return (
    <section id="services" className="py-24 md:py-32 bg-slate-50 dark:bg-slate-900 relative transition-colors">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row justify-between items-end mb-16 md:mb-20 gap-8">
          <div className="max-w-2xl">
            <h2 className="text-blue-600 dark:text-blue-400 font-extrabold uppercase tracking-[0.3em] text-[10px] mb-6">Our Capabilities</h2>
            <h3 className="text-4xl md:text-5xl font-serif italic text-slate-900 dark:text-white">Custom Builds. Pure Code. No Compromise.</h3>
          </div>
          <p className="text-slate-500 dark:text-slate-400 max-w-sm mb-2 text-sm">
            We specialize in scratch-built solutions that avoid the performance tax of generic templates. Your business is unique; your code should be too.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {services.map((service, idx) => (
            <div
              key={idx}
              className="p-10 md:p-12 bg-white dark:bg-slate-950/50 rounded-[32px] border border-slate-200 dark:border-white/5 group hover:border-blue-500 dark:hover:border-blue-400 hover:shadow-2xl hover:shadow-blue-500/5 transition-all duration-500 flex flex-col justify-between"
            >
              <div>
                <div className="flex justify-between items-start mb-10">
                  <div className="w-14 h-14 bg-slate-50 dark:bg-slate-900 rounded-2xl flex items-center justify-center text-blue-600 dark:text-blue-400 group-hover:bg-blue-600 group-hover:text-white transition-colors duration-500">
                      <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d={service.icon} />
                      </svg>
                  </div>
                  <span className="text-4xl font-serif italic text-slate-100 dark:text-slate-800 group-hover:text-blue-50 dark:group-hover:text-blue-900/30 transition-colors">0{idx+1}</span>
                </div>
                <h4 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">{service.title}</h4>
                <p className="text-slate-500 dark:text-slate-400 leading-relaxed mb-8">{service.desc}</p>
              </div>
              <button 
                type="button" 
                onClick={() => onOpenCaseStudy(service.caseStudy)}
                className="text-xs font-bold uppercase tracking-widest text-blue-600 dark:text-blue-400 flex items-center group-hover:translate-x-2 transition-transform focus:outline-none"
              >
                View From-Scratch Case
                <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;
