
import React, { useEffect } from 'react';
import { CaseStudy } from '../types';

interface CaseStudyPageProps {
  caseStudy: CaseStudy;
  onBack: () => void;
  onRequestAnalysis: () => void;
}

const CaseStudyPage: React.FC<CaseStudyPageProps> = ({ caseStudy, onBack, onRequestAnalysis }) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [caseStudy.id]);

  const themeClasses: Record<string, { bg: string, text: string, accent: string, glow: string, bgSoft: string }> = {
    blue: { bg: 'bg-blue-600', text: 'text-blue-400', accent: 'text-blue-600', glow: 'shadow-blue-500/20', bgSoft: 'bg-blue-50' },
    emerald: { bg: 'bg-emerald-600', text: 'text-emerald-400', accent: 'text-emerald-600', glow: 'shadow-emerald-500/20', bgSoft: 'bg-emerald-50' },
    indigo: { bg: 'bg-indigo-600', text: 'text-indigo-400', accent: 'text-indigo-600', glow: 'shadow-indigo-500/20', bgSoft: 'bg-indigo-50' },
    rose: { bg: 'bg-rose-600', text: 'text-rose-400', accent: 'text-rose-600', glow: 'shadow-rose-500/20', bgSoft: 'bg-rose-50' },
  };

  const theme = themeClasses[caseStudy.themeColor] || themeClasses.blue;

  // Select a lead based on project ID for variety
  const leads = [
    { name: 'Aarav Sharma', role: 'Lead Systems Architect', img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100' },
    { name: 'Ananya Iyer', role: 'Senior Product Strategist', img: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100' },
    { name: 'Rohan Deshmukh', role: 'Full-Stack Lead Engineer', img: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=100' }
  ];
  const lead = leads[caseStudy.id % leads.length];

  return (
    <div className="min-h-screen bg-white animate-fadeIn">
      {/* Dynamic Header with Unique Background */}
      <header className="relative min-h-[60vh] md:h-[80vh] flex items-end bg-slate-900 overflow-hidden">
        <div className="absolute inset-0">
           <img 
            src={caseStudy.heroImage} 
            alt={caseStudy.client} 
            className="w-full h-full object-cover opacity-60 scale-105"
          />
        </div>
        <div className={`absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/60 to-transparent`}></div>
        
        {/* Subtle dynamic overlay */}
        <div className={`absolute inset-0 opacity-10 ${theme.bg}`}></div>

        <div className="max-w-7xl mx-auto px-6 w-full pb-12 md:pb-20 relative z-10">
          <button 
            type="button" 
            onClick={onBack}
            className="flex items-center space-x-2 text-white/60 hover:text-white transition-colors mb-8 md:mb-12 group"
          >
            <svg className="w-5 h-5 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            <span className="text-xs font-bold uppercase tracking-widest">Exit Case Study</span>
          </button>
          
          <div className="flex items-center space-x-4 mb-6 md:mb-8">
            <span className={`text-[10px] uppercase tracking-[0.5em] font-black ${theme.text}`}>Scratch Build Dossier #{caseStudy.id}</span>
            <span className="w-8 md:w-12 h-px bg-white/20"></span>
          </div>
          <h1 className="text-4xl sm:text-6xl md:text-8xl lg:text-9xl font-serif italic text-white leading-[1] md:leading-[0.85] max-w-6xl mb-8 md:mb-10 tracking-tighter">
            {caseStudy.title}
          </h1>
          <div className="flex flex-wrap items-center gap-4 md:gap-6">
             <div className="flex items-center space-x-3 bg-white/5 backdrop-blur-md px-4 py-2 rounded-full border border-white/10">
                <div className={`w-2 h-2 rounded-full ${theme.bg} animate-pulse`}></div>
                <p className="text-white/80 text-[10px] font-black uppercase tracking-widest">Bespoke Engineering</p>
             </div>
             <div className="flex items-center space-x-3 bg-white/5 backdrop-blur-md px-4 py-2 rounded-full border border-white/10">
                <p className="text-white/80 text-[10px] font-black uppercase tracking-widest">Team: India Core</p>
             </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-16 md:py-32">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-24 items-start">
          <div className="lg:col-span-7 space-y-20 md:space-y-32">
            <section>
              <div className={`text-[10px] font-black uppercase tracking-widest ${theme.text} mb-8 md:mb-10`}>The Partnership</div>
              <div className="text-4xl md:text-6xl font-bold text-slate-900 mb-8 md:mb-10 tracking-tight leading-none">{caseStudy.client}</div>
              <p className="text-xl md:text-2xl text-slate-500 font-light leading-relaxed">
                Transforming a business of this scale required zero templates. We rebuilt their digital architecture from the ground up to ensure absolute security and speed.
              </p>
            </section>

            <div className="space-y-16 md:space-y-20">
              <section className="relative group">
                <div className={`absolute -left-6 md:-left-8 top-0 bottom-0 w-1 ${theme.bg} opacity-20`}></div>
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-900 mb-6 md:mb-8 flex items-center">
                  <span className={`w-6 h-6 rounded-full ${theme.bgSoft} flex items-center justify-center mr-4`}>
                    <span className={`w-2 h-2 rounded-full ${theme.bg}`}></span>
                  </span>
                  The Challenge
                </h3>
                <p className="text-lg md:text-xl text-slate-600 leading-relaxed font-light">{caseStudy.challenge}</p>
              </section>

              <section className="relative group">
                <div className={`absolute -left-6 md:-left-8 top-0 bottom-0 w-1 ${theme.bg} opacity-20`}></div>
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-900 mb-6 md:mb-8 flex items-center">
                  <span className={`w-6 h-6 rounded-full ${theme.bgSoft} flex items-center justify-center mr-4`}>
                    <span className={`w-2 h-2 rounded-full ${theme.bg}`}></span>
                  </span>
                  Scratch-Build Solution
                </h3>
                <p className="text-lg md:text-xl text-slate-600 leading-relaxed font-light">{caseStudy.solution}</p>
              </section>
            </div>

            <section className={`p-10 md:p-16 rounded-[40px] md:rounded-[60px] ${theme.bgSoft} border border-slate-100 relative overflow-hidden`}>
               <div className="absolute top-0 right-0 w-48 md:w-64 h-48 md:h-64 bg-white opacity-40 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl"></div>
               <h3 className="text-xs font-black uppercase tracking-widest text-slate-900 mb-8 md:mb-10">Economic Outcome</h3>
               <p className="text-2xl md:text-5xl font-serif italic text-slate-800 leading-tight">
                 "{caseStudy.result}"
               </p>
            </section>
          </div>

          <aside className="lg:col-span-5 lg:sticky lg:top-32">
            <div className="bg-slate-900 rounded-[40px] md:rounded-[56px] p-10 md:p-16 text-white shadow-3xl shadow-slate-900/40 relative overflow-hidden">
                <div className={`absolute top-0 left-0 w-full h-1 ${theme.bg}`}></div>
                <div className="flex justify-between items-center mb-12 md:member-16">
                   <h3 className={`text-[10px] font-black uppercase tracking-[0.3em] ${theme.text}`}>Affordable Excellence</h3>
                   <div className={`w-10 h-10 md:w-12 md:h-12 rounded-xl md:rounded-2xl ${theme.bg} flex items-center justify-center`}>
                      <svg className="w-5 h-5 md:w-6 md:h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2-2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                      </svg>
                   </div>
                </div>
                
                <div className="space-y-10 md:space-y-12">
                  {caseStudy.metrics.map((metric, i) => (
                    <div key={i} className="group border-b border-white/5 pb-8 md:pb-10 last:border-0 last:pb-0">
                      <div className="text-5xl md:text-7xl font-extrabold mb-2 md:mb-3 tracking-tighter group-hover:text-blue-400 transition-colors duration-500">{metric.value}</div>
                      <div className="text-[10px] uppercase tracking-[0.4em] font-black opacity-30">{metric.label}</div>
                    </div>
                  ))}
                </div>
                
                <button 
                  type="button"
                  onClick={onRequestAnalysis}
                  className={`w-full mt-12 md:mt-16 ${theme.bg} hover:opacity-90 text-white py-6 rounded-2xl md:rounded-3xl text-[10px] font-black uppercase tracking-[0.3em] transition-all active:scale-95 shadow-xl`}
                >
                  Hire This Team
                </button>
            </div>
            
            <div 
              onClick={onRequestAnalysis}
              className="mt-8 md:mt-12 p-6 md:p-8 border border-slate-100 rounded-[30px] md:rounded-[40px] flex items-center justify-between group cursor-pointer hover:bg-slate-50 transition-colors"
            >
               <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-slate-200 overflow-hidden border-2 border-white shadow-sm">
                     <img src={lead.img} alt={lead.name} className="w-full h-full object-cover" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-widest text-slate-900">{lead.role}</p>
                    <p className="text-sm font-bold text-slate-700">{lead.name}</p>
                  </div>
               </div>
               <svg className="w-5 h-5 text-slate-300 group-hover:text-blue-600 group-hover:translate-x-1 transition-all" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
               </svg>
            </div>
          </aside>
        </div>
      </main>

      <footer className="py-16 md:py-24 bg-slate-50 border-t border-slate-100">
         <div className="max-w-7xl mx-auto px-6 text-center">
            <h4 className="text-[10px] font-black uppercase tracking-[0.5em] text-slate-400 mb-10 md:mb-12">Affordable Scratch-Built Tech</h4>
            <div className="flex flex-col md:flex-row items-center justify-center gap-6 md:gap-8">
               <button 
                onClick={onBack}
                className="text-slate-900 font-serif italic text-2xl md:text-3xl hover:text-blue-600 transition-colors"
               >
                 Custom Web Apps
               </button>
               <span className="hidden md:block w-1 h-1 bg-slate-300 rounded-full"></span>
               <button 
                onClick={onBack}
                className="text-slate-900 font-serif italic text-2xl md:text-3xl hover:text-blue-600 transition-colors"
               >
                 Software Engineering
               </button>
               <span className="hidden md:block w-1 h-1 bg-slate-300 rounded-full"></span>
               <button 
                onClick={onBack}
                className="text-slate-900 font-serif italic text-2xl md:text-3xl hover:text-blue-600 transition-colors"
               >
                 AI Data Lab
               </button>
            </div>
         </div>
      </footer>
    </div>
  );
};

export default CaseStudyPage;
