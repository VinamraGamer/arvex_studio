
import React from 'react';
import { scrollToSection } from '../utils/navigation';
import Logo from './Logo';

interface FooterProps {
  onOpenAdmin?: () => void;
  isDarkMode?: boolean;
}

const Footer: React.FC<FooterProps> = ({ onOpenAdmin, isDarkMode }) => {
  return (
    <footer className="py-20 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-white/5 transition-colors">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-12">
          <div>
            <div className="mb-6">
              <Logo className="cursor-pointer" light={isDarkMode} />
            </div>
            <p className="max-w-xs text-[10px] uppercase tracking-widest font-bold text-slate-400 dark:text-slate-500 leading-loose">
              Architecting the systems of tomorrow with radical precision and Indian engineering excellence. Custom builds since 2 years.
            </p>
          </div>

          <div className="flex flex-wrap gap-12 md:gap-20">
            <div>
              <div className="text-[10px] uppercase tracking-[0.3em] font-black text-slate-900 dark:text-white mb-6">Directory</div>
              <ul className="space-y-4">
                <li><button type="button" onClick={() => scrollToSection('about')} className="text-[10px] uppercase tracking-widest font-bold text-slate-500 dark:text-slate-400 hover:text-blue-600 transition-colors focus:outline-none">About</button></li>
                <li><button type="button" onClick={() => scrollToSection('services')} className="text-[10px] uppercase tracking-widest font-bold text-slate-500 dark:text-slate-400 hover:text-blue-600 transition-colors focus:outline-none">Solutions</button></li>
                <li><button type="button" onClick={() => scrollToSection('ai-consultant')} className="text-[10px] uppercase tracking-widest font-bold text-slate-500 dark:text-slate-400 hover:text-blue-600 transition-colors focus:outline-none">Intelligence</button></li>
              </ul>
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-[0.3em] font-black text-slate-900 dark:text-white mb-6">Internal</div>
              <ul className="space-y-4">
                <li>
                  <button type="button" onClick={onOpenAdmin} className="text-[10px] uppercase tracking-widest font-black text-blue-600 dark:text-blue-400 hover:underline transition-colors focus:outline-none">
                    Admin Portal
                  </button>
                </li>
                <li><button type="button" className="text-[10px] uppercase tracking-widest font-bold text-slate-500 dark:text-slate-400 hover:text-blue-600 transition-colors focus:outline-none">Security Core</button></li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="mt-20 flex flex-col md:flex-row justify-between items-center gap-6 pt-10 border-t border-slate-200 dark:border-white/5">
          <div className="text-[10px] uppercase tracking-widest font-bold text-slate-400 dark:text-slate-600">
            © 2026 Arvex Studio. Hand-Coded with Precision.
          </div>
          <div className="flex items-center space-x-2">
             <div className="w-2 h-2 rounded-full bg-blue-600"></div>
             <span className="text-[10px] uppercase tracking-widest font-black text-slate-900 dark:text-white">Status: Operational</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
