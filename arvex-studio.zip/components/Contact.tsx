
import React, { useState, useEffect } from 'react';
import { Inquiry, UserProfile } from '../types';

interface ContactProps {
  userProfile?: UserProfile | null;
  isClientAuthenticated?: boolean;
}

const Contact: React.FC<ContactProps> = ({ userProfile, isClientAuthenticated }) => {
  const [status, setStatus] = useState<'idle' | 'sending' | 'success'>('idle');
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });

  // Automatically fill the form if the user is authenticated
  useEffect(() => {
    if (isClientAuthenticated && userProfile && userProfile.name !== 'Guest User') {
      setFormData(prev => ({
        ...prev,
        name: userProfile.name || prev.name,
        email: userProfile.email || prev.email
      }));
    } else if (!isClientAuthenticated) {
      // Clear fields if signed out
      setFormData(prev => ({ ...prev, name: '', email: '' }));
    }
  }, [userProfile, isClientAuthenticated]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('sending');
    
    const newInquiry: Inquiry = {
      id: Math.random().toString(36).substr(2, 9),
      name: formData.name,
      email: formData.email,
      message: formData.message,
      timestamp: Date.now(),
      status: 'new'
    };

    const existing = JSON.parse(localStorage.getItem('arvex_inquiries') || '[]');
    localStorage.setItem('arvex_inquiries', JSON.stringify([newInquiry, ...existing]));

    setTimeout(() => {
      setStatus('success');
      // Retain identity but clear message
      setFormData(prev => ({ 
        name: isClientAuthenticated && userProfile?.name && userProfile.name !== 'Guest User' ? userProfile.name : '', 
        email: isClientAuthenticated && userProfile?.email ? userProfile.email : '', 
        message: '' 
      }));
    }, 1500);
  };

  return (
    <section id="contact" className="py-32 bg-white dark:bg-slate-950 transition-colors">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
          <div>
            <h2 className="text-blue-600 dark:text-blue-400 font-extrabold uppercase tracking-[0.3em] text-[10px] mb-6">Contact</h2>
            <h3 className="text-5xl md:text-7xl font-serif italic text-slate-900 dark:text-white mb-12">
              Ready to <span className="not-italic font-sans font-extrabold text-slate-900 dark:text-white">Elevate</span>?
            </h3>
            
            <div className="space-y-12">
                <div className="flex items-start space-x-6">
                    <div className="w-12 h-12 bg-blue-50 dark:bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-600 dark:text-blue-400 flex-shrink-0">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-900 dark:text-white mb-1 uppercase tracking-tighter text-sm">Official Inquiry</h4>
                        <a href="mailto:officialarvexstudio@gmail.com" className="text-blue-600 dark:text-blue-400 font-bold hover:underline">officialarvexstudio@gmail.com</a>
                        <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">General partnership and project scoping</p>
                    </div>
                </div>
                <div className="flex items-start space-x-6">
                    <div className="w-12 h-12 bg-blue-50 dark:bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-600 dark:text-blue-400 flex-shrink-0">
                        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                    </div>
                    <div>
                        <h4 className="font-bold text-slate-900 dark:text-white mb-1 uppercase tracking-tighter text-sm">Support Protocol</h4>
                        <a href="mailto:officialarvexstudio@gmail.com" className="text-slate-500 dark:text-slate-400 font-medium hover:text-blue-600 transition-colors">officialarvexstudio@gmail.com</a>
                        <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">Technical assistance for existing partners</p>
                    </div>
                </div>
            </div>
          </div>

          <div className="bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-white/5 rounded-[40px] p-8 md:p-16 shadow-2xl shadow-slate-200/50 dark:shadow-none">
            {status === 'success' ? (
                <div className="text-center py-20 animate-fadeIn text-slate-900 dark:text-white">
                    <div className="w-20 h-20 bg-blue-100 dark:bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-8">
                        <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
                    </div>
                    <h4 className="text-2xl font-bold mb-4">Inquiry Logged</h4>
                    <p className="text-slate-500 dark:text-slate-400">Our engineering leads are reviewing your case.</p>
                    <button 
                      onClick={() => setStatus('idle')}
                      className="mt-8 text-xs font-black uppercase tracking-widest text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      Send another message
                    </button>
                </div>
            ) : (
                <form onSubmit={handleSubmit} className="space-y-10">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                        <label className="text-[10px] uppercase tracking-widest font-black text-slate-400 dark:text-slate-500">Identity</label>
                        <input 
                          type="text" required value={formData.name}
                          onChange={(e) => setFormData({...formData, name: e.target.value})}
                          className="w-full bg-transparent border-b border-slate-200 dark:border-slate-800 py-3 focus:outline-none focus:border-blue-500 transition-all font-bold text-slate-900 dark:text-white" 
                          placeholder="Full Name" 
                        />
                    </div>
                    <div className="space-y-2">
                        <label className="text-[10px] uppercase tracking-widest font-black text-slate-400 dark:text-slate-500">Electronic Mail</label>
                        <input 
                          type="email" required value={formData.email}
                          onChange={(e) => setFormData({...formData, email: e.target.value})}
                          className="w-full bg-transparent border-b border-slate-200 dark:border-slate-800 py-3 focus:outline-none focus:border-blue-500 transition-all font-bold text-slate-900 dark:text-white" 
                          placeholder="work@company.com" 
                        />
                    </div>
                </div>
                <div className="space-y-2">
                    <label className="text-[10px] uppercase tracking-widest font-black text-slate-400 dark:text-slate-500">Challenge Narrative</label>
                    <textarea 
                      required value={formData.message}
                      onChange={(e) => setFormData({...formData, message: e.target.value})}
                      className="w-full bg-transparent border-b border-slate-200 dark:border-slate-800 py-3 focus:outline-none focus:border-blue-500 transition-all font-bold text-slate-900 dark:text-white resize-none" 
                      rows={3} placeholder="How can we help?"
                    ></textarea>
                </div>
                <button 
                    type="submit" 
                    className="w-full bg-blue-600 text-white py-6 rounded-2xl font-black uppercase tracking-[0.2em] text-xs hover:bg-blue-700 transition-all shadow-xl shadow-blue-500/20 active:scale-[0.98]"
                >
                    Initiate Inquiry
                </button>
                </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
