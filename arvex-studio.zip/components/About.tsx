
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-20 md:py-32 bg-white dark:bg-slate-950 transition-colors">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 md:mb-24 max-w-3xl mx-auto">
          <h2 className="text-blue-600 dark:text-blue-400 font-extrabold uppercase tracking-[0.3em] text-[10px] mb-4 md:mb-6">The Arvex Standard</h2>
          <h3 className="text-3xl md:text-5xl font-serif italic text-slate-900 dark:text-white leading-tight">
            We don't do "Basic." We build <br className="hidden md:block" />
            <span className="not-italic font-sans font-extrabold text-blue-600 dark:text-blue-400">Bespoke & Affordable.</span>
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
          {[
            { 
              title: 'Zero Templates', 
              desc: 'Every project starts with a blank editor. We write the HTML, CSS, and Logic from scratch to ensure peak performance and unique identity.', 
              icon: 'M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4' 
            },
            { 
              title: 'Enterprise Quality, Boutique Rates', 
              desc: 'By optimizing our internal workflows, we deliver high-end software engineering at price points that actually make sense for your business.', 
              icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' 
            },
            { 
              title: 'Direct Dev Access', 
              desc: 'Skip the account managers. You work directly with the engineers building your site for faster pivots and absolute technical transparency.', 
              icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z' 
            }
          ].map((item, i) => (
            <div key={i} className="p-8 md:p-10 rounded-[32px] bg-slate-50 dark:bg-slate-900 border border-slate-100 dark:border-white/5 hover:bg-white dark:hover:bg-slate-800 hover:shadow-2xl hover:-translate-y-2 transition-all duration-500 group">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-600 dark:text-blue-400 mb-6 md:mb-8 transition-colors group-hover:bg-blue-600 group-hover:text-white">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={item.icon} />
                </svg>
              </div>
              <h4 className="text-xl font-bold text-slate-900 dark:text-white mb-4">{item.title}</h4>
              <p className="text-slate-500 dark:text-slate-400 leading-relaxed text-sm">{item.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-20 md:mt-32 p-10 md:p-12 bg-slate-900 dark:bg-slate-900/50 rounded-[32px] md:rounded-[40px] border border-transparent dark:border-white/5 grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12 text-white text-center">
            {[
                { l: 'Custom Builds', v: '200+' },
                { l: 'Template Usage', v: '0%' },
                { l: 'Client Savings', v: '35% Avg' },
                { l: 'Launch Speed', v: '4 Weeks' },
            ].map((s, i) => (
                <div key={i}>
                    <div className="text-2xl md:text-4xl font-extrabold mb-1 md:mb-2 text-blue-400">{s.v}</div>
                    <div className="text-[10px] uppercase tracking-widest font-bold opacity-50">{s.l}</div>
                </div>
            ))}
        </div>
      </div>
    </section>
  );
};

export default About;
