
import React, { useState } from 'react';
import { getAIRecommendation } from '../services/gemini';

interface AIConsultantProps {
  onInteract: () => void;
}

const AIConsultant: React.FC<AIConsultantProps> = ({ onInteract }) => {
  const [problem, setProblem] = useState('');
  const [recommendation, setRecommendation] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleConsult = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!problem.trim() || isLoading) return;
    
    onInteract();
    setIsLoading(true);
    setRecommendation('');
    try {
      const result = await getAIRecommendation(problem);
      setRecommendation(result);
    } catch (err) {
      setRecommendation('Consultant Offline: Our strategic engine is currently undergoing maintenance. Please try again shortly or contact a partner directly.');
    } finally {
      setIsLoading(false);
    }
  };

  const formatText = (text: string) => {
    return text.split('\n').map((line, i) => {
      let formattedLine = line.replace(/\*\*(.*?)\*\*/g, '<strong class="text-white font-bold">$1</strong>');
      if (formattedLine.trim().startsWith('- ') || formattedLine.trim().startsWith('* ')) {
        return <li key={i} className="ml-4 mb-2 list-none flex items-start">
          <span className="text-blue-500 mr-2 flex-shrink-0">/</span>
          <span dangerouslySetInnerHTML={{ __html: formattedLine.replace(/^[-*]\s/, '') }} />
        </li>;
      }
      if (/^\d+\./.test(formattedLine.trim())) {
        return <div key={i} className="mb-4 text-blue-400 font-bold uppercase tracking-widest text-xs mt-8 first:mt-0">
           <span dangerouslySetInnerHTML={{ __html: formattedLine }} />
        </div>;
      }
      return <p key={i} className="mb-4 last:mb-0" dangerouslySetInnerHTML={{ __html: formattedLine }} />;
    });
  };

  return (
    <section id="ai-consultant" className="py-20 md:py-32 bg-white dark:bg-slate-950 transition-colors">
      <div className="max-w-6xl mx-auto px-6">
        <div className="bg-slate-900 dark:bg-slate-900/50 border border-transparent dark:border-white/5 rounded-[30px] md:rounded-[40px] p-8 md:p-20 text-white relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
            <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] md:w-[800px] h-[400px] md:h-[800px] bg-blue-600 rounded-full blur-[160px] transition-all duration-1000 ${isLoading ? 'opacity-40 scale-110' : 'opacity-20 scale-100'}`}></div>
          </div>

          <div className="relative z-10">
            <div className="flex items-center space-x-3 mb-8 md:mb-10">
              <div className="flex space-x-1">
                <div className={`w-1.5 h-1.5 bg-blue-500 rounded-full ${isLoading ? 'animate-bounce' : ''}`}></div>
                <div className={`w-1.5 h-1.5 bg-blue-500 rounded-full ${isLoading ? 'animate-bounce [animation-delay:0.2s]' : ''}`}></div>
                <div className={`w-1.5 h-1.5 bg-blue-500 rounded-full ${isLoading ? 'animate-bounce [animation-delay:0.4s]' : ''}`}></div>
              </div>
              <span className="text-[10px] uppercase tracking-[0.4em] font-black text-blue-400">Arvex Engineering Lab</span>
            </div>

            <h2 className="text-3xl md:text-6xl font-serif italic mb-10 md:mb-12 text-white">
              Software Project <br className="hidden md:block" />
              <span className="not-italic font-sans font-extrabold text-blue-400">Scoping Engine.</span>
            </h2>

            <form onSubmit={handleConsult} className="relative mb-10 md:mb-12 max-w-3xl">
              <div className="flex flex-col md:block relative">
                <input
                  type="text"
                  value={problem}
                  onChange={(e) => setProblem(e.target.value)}
                  placeholder="e.g. Building a real-time marketplace app..."
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-6 md:px-8 py-5 md:py-6 text-base md:text-lg focus:outline-none focus:border-blue-500 transition-all font-light placeholder:text-slate-600 mb-4 md:mb-0 text-white"
                />
                <button
                  type="submit"
                  disabled={isLoading}
                  className="md:absolute md:right-3 md:top-3 md:bottom-3 px-8 py-5 md:py-0 bg-blue-600 text-white font-bold uppercase text-xs rounded-xl hover:bg-blue-500 transition-colors disabled:opacity-50 active:scale-95 flex items-center justify-center min-w-[180px]"
                >
                  {isLoading ? 'Analyzing...' : 'Scope Project'}
                </button>
              </div>
            </form>

            <div className={`min-h-[200px] border border-white/5 rounded-2xl md:rounded-3xl p-6 md:p-12 bg-black/20 backdrop-blur-sm transition-all duration-500 ${recommendation ? 'opacity-100 translate-y-0' : 'opacity-80'}`}>
              {!recommendation && !isLoading ? (
                <div className="flex flex-col items-center justify-center h-48 text-slate-500">
                  <p className="text-[10px] uppercase tracking-[0.2em] font-bold text-center">Architectural Core Standby</p>
                </div>
              ) : isLoading ? (
                <div className="flex flex-col space-y-6 animate-pulse py-4">
                  <div className="h-4 bg-white/5 rounded w-3/4"></div>
                  <div className="h-4 bg-white/5 rounded w-1/2"></div>
                </div>
              ) : (
                <div className="animate-fadeIn max-w-none">
                  <div className="text-slate-300 leading-relaxed font-light text-sm md:text-base">
                    {formatText(recommendation)}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIConsultant;
