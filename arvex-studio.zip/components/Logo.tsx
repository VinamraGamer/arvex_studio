
import React from 'react';

interface LogoProps {
  className?: string;
  iconOnly?: boolean;
  light?: boolean; // Now optional/override, as it uses dark mode classes by default
}

const Logo: React.FC<LogoProps> = ({ className = "", iconOnly = false, light }) => {
  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      <div className="relative w-8 h-8 md:w-9 md:h-9 flex-shrink-0">
        <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full transition-transform duration-500 hover:scale-110">
          {/* Hexagonal structural frame - reacting to dark mode via opacity if needed or fixed light colors */}
          <path 
            d="M20 4L33.8564 12V28L20 36L6.14359 28V12L20 4Z" 
            className="fill-blue-50 dark:fill-white/10"
          />
          {/* Main "A" geometry - stays blue */}
          <path 
            d="M20 10L30 30H24L20 20L16 30H10L20 10Z" 
            fill="#2563EB" 
          />
          {/* Technical connecting node - dark in light mode, light blue in dark mode */}
          <circle cx="20" cy="10" r="3" className="fill-slate-900 dark:fill-blue-400" />
          {/* Precision cross-bar */}
          <rect x="17" y="24" width="6" height="1.5" fill="white" />
        </svg>
      </div>
      {!iconOnly && (
        <span className={`text-xl md:text-2xl font-black tracking-tighter text-slate-900 dark:text-white`}>
          Arvex<span className="text-blue-600">.</span>
        </span>
      )}
    </div>
  );
};

export default Logo;
