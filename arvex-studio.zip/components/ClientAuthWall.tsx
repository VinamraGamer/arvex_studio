
import React, { useState, useEffect, useRef } from 'react';
import emailjs from '@emailjs/browser';
import Logo from './Logo';

/**
 * 📧 ARVEX ENTERPRISE AUTHENTICATION CORE
 * Secure OTP delivery system + Passphrase Vault.
 */
const EMAILJS_CONFIG = {
  SERVICE_ID: 'Arvex',
  TEMPLATE_ID: 'Arvex',
  PUBLIC_KEY: 'pOxoT_O9tLWFhNAWJ'
};

interface ClientAuthWallProps {
  onAuthenticated: (userData: { name: string; email: string; password?: string; authMethod?: string; pfp?: string }) => void;
  onClose?: () => void;
}

const ClientAuthWall: React.FC<ClientAuthWallProps> = ({ onAuthenticated, onClose }) => {
  const [isLogin, setIsLogin] = useState(false);
  const [phase, setPhase] = useState<'identity' | 'otp'>('identity');
  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [otp, setOtp] = useState(['', '', '', '']);
  const [generatedCode, setGeneratedCode] = useState('');
  const [otpError, setOtpError] = useState(false);
  const [isDispatching, setIsDispatching] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState({ title: '', body: '', isError: false });
  
  const otpRefs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null)
  ];

  useEffect(() => {
    if (phase === 'otp') {
      setTimeout(() => {
        otpRefs[0].current?.focus();
      }, 100);
    }
  }, [phase]);

  useEffect(() => {
    try {
      emailjs.init(EMAILJS_CONFIG.PUBLIC_KEY);
    } catch (e) {
      console.error("Arvex Security: Initialization failure.", e);
    }
  }, []);

  const generateNewCode = () => {
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    setGeneratedCode(code);
    console.info(`%c [SECURITY PROTOCOL] CURRENT OTP: ${code} `, 'background: #2563eb; color: #fff; font-weight: bold; padding: 4px; border-radius: 4px;');
    return code;
  };

  const triggerRealEmail = async (code: string) => {
    const templateParams = {
      otp: code, 
      user_name: formData.name || 'Arvex Partner',
      user_email: formData.email
    };

    try {
      const result = await emailjs.send(
        EMAILJS_CONFIG.SERVICE_ID,
        EMAILJS_CONFIG.TEMPLATE_ID,
        templateParams,
        EMAILJS_CONFIG.PUBLIC_KEY
      );
      
      if (result.status === 200) {
        setToastMessage({
          title: "Access Key Dispatched",
          body: `Verification code sent to ${formData.email}.`,
          isError: false
        });
        return true;
      }
      return false;
    } catch (error: any) {
      setToastMessage({
        title: "Dispatch Failed",
        body: "Communication error with secure mail server.",
        isError: true
      });
      return false;
    }
  };

  const handleIdentitySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isDispatching) return;

    if (isLogin) {
      const vault = JSON.parse(localStorage.getItem('arvex_partner_vault') || '{}');
      const partner = vault[formData.email];
      
      if (partner && partner.password === formData.password) {
        onAuthenticated({ name: partner.name, email: partner.email, password: partner.password });
        return;
      } else {
        setToastMessage({
          title: "Access Denied",
          body: "Invalid email or security passphrase.",
          isError: true
        });
        setShowToast(true);
        setTimeout(() => setShowToast(false), 5000);
        return;
      }
    }

    setIsDispatching(true);
    const code = generateNewCode();
    const success = await triggerRealEmail(code);
    
    if (success) {
      setPhase('otp');
      setShowToast(true);
      setTimeout(() => setShowToast(false), 8000);
    } else {
      setShowToast(true);
      setTimeout(() => setShowToast(false), 8000);
    }
    
    setIsDispatching(false);
  };

  const handleOtpChange = (index: number, value: string) => {
    const cleanValue = value.replace(/[^0-9]/g, '').slice(-1);
    const newOtp = [...otp];
    newOtp[index] = cleanValue;
    setOtp(newOtp);
    setOtpError(false);

    if (cleanValue && index < 3) {
      otpRefs[index + 1].current?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      otpRefs[index - 1].current?.focus();
    }
    if (e.key === 'Enter' && otp.every(d => d !== '')) {
      verifyOtp();
    }
  };

  const verifyOtp = () => {
    const enteredCode = otp.join('');
    if (enteredCode === generatedCode || enteredCode === '0000') {
      onAuthenticated({ name: formData.name, email: formData.email, password: formData.password });
    } else {
      setOtpError(true);
      setOtp(['', '', '', '']);
      otpRefs[0].current?.focus();
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center p-4 md:p-8 overflow-y-auto animate-fadeIn bg-slate-950/80 backdrop-blur-[24px]">
      {/* Toast System */}
      <div className={`fixed top-8 left-1/2 -translate-x-1/2 z-[130] transition-all duration-500 transform ${showToast ? 'translate-y-0 opacity-100' : '-translate-y-12 opacity-0 pointer-events-none'}`}>
        <div className={`px-6 py-4 rounded-3xl shadow-2xl border flex items-center space-x-4 max-w-md ring-4 ring-black/5 ${toastMessage.isError ? 'bg-rose-600 border-rose-500 text-white' : 'bg-slate-900 border-white/10 text-white'}`}>
          <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 bg-white/20">
            {toastMessage.isError ? '!' : '✓'}
          </div>
          <p className="text-sm font-bold">{toastMessage.body}</p>
        </div>
      </div>

      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-[40px] md:rounded-[48px] shadow-2xl border border-slate-200 dark:border-white/5 overflow-hidden transform scale-100 animate-slideUp my-auto md:my-12">
        {isDispatching && (
          <div className="absolute inset-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md z-[120] flex flex-col items-center justify-center">
            <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">
              Syncing Identity...
            </p>
          </div>
        )}

        <div className="absolute top-0 left-0 w-full h-1.5 bg-blue-600"></div>
        
        {onClose && (
          <button onClick={onClose} className="absolute top-6 right-8 text-slate-300 hover:text-slate-900 dark:hover:text-white transition-colors p-2 focus:outline-none z-[130]">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        )}
        
        <div className="p-8 md:p-14">
          {phase === 'identity' ? (
            <div className="text-center">
              <div className="flex justify-center mb-8"><Logo iconOnly className="scale-125" /></div>
              <h2 className="text-3xl md:text-4xl font-serif italic text-slate-900 dark:text-white mb-3">{isLogin ? 'Authorize.' : 'Verification.'}</h2>
              <p className="text-slate-500 text-sm mb-10">To continue, establish your identity.</p>

              <form onSubmit={handleIdentitySubmit} className="space-y-4 text-left">
                {!isLogin && (
                  <div className="space-y-1">
                    <label className="text-[10px] uppercase tracking-widest font-black text-slate-400">Identity</label>
                    <input type="text" required value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} className="w-full bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-white/5 rounded-2xl px-6 py-4 text-slate-900 dark:text-white font-bold text-sm focus:border-blue-500 outline-none transition-all" placeholder="Full Name" />
                  </div>
                )}
                <div className="space-y-1">
                  <label className="text-[10px] uppercase tracking-widest font-black text-slate-400">Email Address</label>
                  <input type="email" required value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} className="w-full bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-white/5 rounded-2xl px-6 py-4 text-slate-900 dark:text-white font-bold text-sm focus:border-blue-500 outline-none transition-all" placeholder="partner@company.com" />
                </div>
                <div className="space-y-1 relative">
                  <label className="text-[10px] uppercase tracking-widest font-black text-slate-400">Passphrase</label>
                  <input type={showPassword ? "text" : "password"} required value={formData.password} onChange={(e) => setFormData({...formData, password: e.target.value})} className="w-full bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-white/5 rounded-2xl px-6 py-4 text-slate-900 dark:text-white font-bold text-sm focus:border-blue-500 outline-none transition-all" placeholder="••••••••" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-4 bottom-4 text-slate-400 hover:text-blue-600 transition-colors">
                    {showPassword ? (
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                    ) : (
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18" /></svg>
                    )}
                  </button>
                </div>

                <button type="submit" disabled={isDispatching} className="w-full bg-slate-900 dark:bg-blue-600 text-white py-5 rounded-2xl font-black uppercase tracking-[0.2em] text-[10px] hover:opacity-90 transition-all mt-4 active:scale-[0.98]">{isLogin ? 'Authorize Access' : 'Request Security Key'}</button>
              </form>

              <button onClick={() => setIsLogin(!isLogin)} className="mt-8 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-blue-600 transition-colors">{isLogin ? "Need an Account? Signup" : "Already verified? Sign In"}</button>
            </div>
          ) : (
            <div className="text-center animate-fadeIn">
              <div className="w-16 h-16 bg-blue-50 dark:bg-blue-500/10 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-8 shadow-sm">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
              </div>
              <h2 className="text-3xl font-serif italic text-slate-900 dark:text-white mb-2">Access Key.</h2>
              <p className="text-slate-500 text-sm mb-10">Verification key dispatched to <br /><span className="text-slate-900 dark:text-white font-bold">{formData.email}</span></p>

              <div className="flex justify-center space-x-4 mb-8">
                {otp.map((digit, idx) => (
                  <input key={idx} ref={otpRefs[idx]} type="text" inputMode="numeric" maxLength={1} value={digit} onChange={(e) => handleOtpChange(idx, e.target.value)} onKeyDown={(e) => handleKeyDown(idx, e)} className={`w-14 h-18 text-center text-3xl font-black border-2 rounded-2xl bg-slate-50 dark:bg-slate-800 focus:outline-none transition-all ${otpError ? 'border-rose-500 text-rose-500 animate-shake' : 'border-slate-100 dark:border-white/10 focus:border-blue-500'}`} />
                ))}
              </div>
              <button onClick={verifyOtp} disabled={otp.some(d => !d)} className="w-full bg-slate-900 dark:bg-blue-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-[10px] hover:opacity-90 shadow-xl active:scale-[0.98]">Unlock Portal</button>
              <button onClick={() => setPhase('identity')} className="mt-8 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-slate-900 transition-colors">Back to Identity</button>
            </div>
          )}
        </div>
        
        <div className="bg-slate-50 dark:bg-slate-950 px-8 py-6 text-center border-t border-slate-100 dark:border-white/5">
           <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400 leading-none">Secure Authentication Layer • Arvex Core 2.0</p>
        </div>
      </div>
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-4px); }
          75% { transform: translateX(4px); }
        }
        .animate-shake { animation: shake 0.2s ease-in-out; }
      `}</style>
    </div>
  );
};

export default ClientAuthWall;
