
import React from 'react';
import { scrollToSection } from '../utils/navigation';

interface HeroProps {
  onInteract: () => void;
}

const Hero: React.FC<HeroProps> = ({ onInteract }) => {
  const handleCta = () => {
    onInteract();
    scrollToSection('contact');
  };

  return (
    <section id="home" className="relative min-h-[90vh] md:min-h-screen flex items-center overflow-hidden pt-20 md:pt-24 hero-gradient transition-all duration-500">
      <div className="max-w-7xl mx-auto px-6 md:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
        <div className="relative z-10 text-center lg:text-left">
          <div className="inline-flex items-center space-x-2 bg-blue-50 dark:bg-blue-500/10 border border-blue-100 dark:border-blue-500/20 px-4 py-1.5 rounded-full mb-6 md:mb-8">
            <span className="flex h-2 w-2 rounded-full bg-blue-500 animate-pulse"></span>
            <span className="text-blue-600 dark:text-blue-400 text-[10px] font-extrabold uppercase tracking-widest">Hand-Coded by India's Elite</span>
          </div>
          
          <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-serif italic text-slate-900 dark:text-white leading-[1.1] md:leading-[0.95] mb-6 md:mb-8 tracking-tight">
            Built From Scratch. <br />
            <span className="not-italic font-sans font-extrabold text-blue-600 dark:text-blue-400 tracking-tighter">Scaled For Success.</span>
          </h1>
          
          <p className="text-lg md:text-xl text-slate-500 dark:text-slate-400 font-light leading-relaxed mb-8 md:mb-12 max-w-lg mx-auto lg:mx-0">
            We build high-performance websites and custom software from the ground up. No templates, no bloat—just clean code by our India-based core team at an affordable scale.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-6">
            <button
              type="button"
              onClick={handleCta}
              className="w-full sm:w-auto px-10 py-5 bg-blue-600 text-white font-bold uppercase tracking-widest text-xs rounded-2xl hover:bg-blue-700 transition-all hover:shadow-2xl hover:shadow-blue-500/20 active:scale-95 text-center focus:outline-none"
            >
              Get a Free Quote
            </button>
            <div className="flex items-center space-x-4">
               <div className="flex -space-x-3">
                {[
                  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100',
                  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100',
                  'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=100'
                ].map((src, i) => (
                  <div key={i} className="w-10 h-10 rounded-full border-2 border-white dark:border-slate-800 overflow-hidden shadow-sm bg-slate-200">
                    <img src={src} alt="Team lead" className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
              <span className="text-[10px] uppercase tracking-widest font-black text-slate-400 dark:text-slate-500">Direct Contact with India's Tech Leads</span>
            </div>
          </div>
        </div>

        <div className="relative hidden lg:block">
            <div className="relative z-10 rounded-[40px] overflow-hidden shadow-2xl transform rotate-3 hover:rotate-0 transition-transform duration-700 border-8 border-white dark:border-slate-800">
                <img 
                    src="https://images.unsplash.com/photo-1587620962725-abab7fe55159?auto=format&fit=crop&q=80&w=1200" 
                    alt="Custom Coding from Scratch"
                    className="w-full h-[600px] object-cover"
                />
            </div>
            <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-blue-600/5 rounded-full blur-3xl"></div>
            
            <div className="absolute top-1/4 -right-12 z-20 glass p-6 rounded-2xl shadow-xl animate-float hidden xl:block">
                <div className="flex items-center space-x-3 mb-3">
                    <div className="w-3 h-3 rounded-full bg-slate-300 dark:bg-slate-700"></div>
                    <div className="w-3 h-3 rounded-full bg-slate-200 dark:bg-slate-800"></div>
                    <div className="w-3 h-3 rounded-full bg-slate-100 dark:bg-slate-900"></div>
                </div>
                <div className="text-[10px] font-black text-blue-600 dark:text-blue-400 uppercase tracking-widest mb-1">Affordable Excellence</div>
                <div className="h-2 w-32 bg-slate-100 dark:bg-slate-800 rounded"></div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
