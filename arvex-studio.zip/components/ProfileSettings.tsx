
import React, { useState, useRef } from 'react';
import { UserProfile } from '../types';

interface ProfileSettingsProps {
  profile: UserProfile;
  isClientAuthenticated: boolean;
  onSave: (updatedProfile: UserProfile) => void;
  onLogout: () => void;
  onClose: () => void;
}

const GUEST_PFP = 'https://cdn-icons-png.flaticon.com/512/149/149071.png';

const ProfileSettings: React.FC<ProfileSettingsProps> = ({ profile, isClientAuthenticated, onSave, onLogout, onClose }) => {
  const [formData, setFormData] = useState<UserProfile>({ ...profile });
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePfpClick = () => {
    if (!isClientAuthenticated) return;
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        alert("Image too large. Please select an image under 2MB.");
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        if (reader.result) {
          setFormData(prev => ({ ...prev, pfp: reader.result as string }));
        }
      };
      reader.onerror = () => {
        console.error("Arvex Security: Profile Image Capture Failure.");
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isClientAuthenticated || isSaving) return;
    
    setIsSaving(true);
    setSaveSuccess(false);

    setTimeout(() => {
      onSave({ ...formData });
      setIsSaving(false);
      setSaveSuccess(true);
      
      setTimeout(() => {
        onClose();
      }, 500);
    }, 800);
  };

  const handleSignOut = () => {
    onLogout();
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 md:p-8 overflow-y-auto animate-fadeIn">
      <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-xl" onClick={onClose}></div>
      
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-[32px] md:rounded-[48px] shadow-3xl border border-slate-200 dark:border-white/5 overflow-hidden my-auto transform scale-100 animate-slideUp">
        <div className="absolute top-0 left-0 w-full h-1.5 bg-blue-600"></div>
        
        <div className="absolute top-6 left-6 md:left-8 right-6 md:right-8 flex justify-between items-center z-10">
          <button 
            onClick={onClose} 
            className="flex items-center space-x-2 text-slate-400 hover:text-slate-900 dark:hover:text-white transition-all group px-3 py-2 rounded-xl bg-white/50 dark:bg-slate-900/50 backdrop-blur-md"
            aria-label="Go back"
          >
            <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center group-hover:bg-slate-200 dark:group-hover:bg-slate-700 transition-colors">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </div>
            <span className="text-[10px] font-black uppercase tracking-widest">Back</span>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 md:p-16 pt-24 md:pt-28">
          <div className="flex flex-col md:flex-row items-center gap-8 md:gap-12 mb-12">
            <div className="flex flex-col items-center space-y-4">
              <div 
                className={`relative group rounded-[32px] overflow-hidden ${isClientAuthenticated ? 'cursor-pointer ring-4 ring-offset-4 ring-transparent hover:ring-blue-600/20 transition-all ring-offset-white dark:ring-offset-slate-900' : 'cursor-not-allowed'}`} 
                onClick={handlePfpClick}
              >
                <div className="w-28 h-28 md:w-32 md:h-32 rounded-[32px] overflow-hidden border-4 border-slate-50 dark:border-slate-800 shadow-xl relative bg-slate-100 dark:bg-slate-800">
                  <img 
                    src={formData.pfp || GUEST_PFP} 
                    alt="Profile" 
                    className={`w-full h-full object-cover transition-transform duration-500 ${isClientAuthenticated ? 'group-hover:scale-110' : ''}`}
                  />
                  
                  {isClientAuthenticated && (
                    <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center transition-opacity duration-300 text-white">
                      <svg className="w-6 h-6 mb-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                      </svg>
                      <span className="text-[8px] font-black uppercase tracking-tighter">Click to Edit</span>
                    </div>
                  )}
                </div>
                
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  className="hidden" 
                  accept="image/*"
                />
              </div>

              {isClientAuthenticated && (
                <button 
                  type="button"
                  onClick={handlePfpClick}
                  className="flex items-center space-x-2 bg-slate-100 dark:bg-slate-800 hover:bg-blue-600 hover:text-white px-4 py-2 rounded-xl transition-all border border-slate-200 dark:border-white/5 group shadow-sm"
                >
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                  </svg>
                  <span className="text-[9px] font-black uppercase tracking-widest">Import From Device</span>
                </button>
              )}
            </div>

            <div className="text-center md:text-left">
              <h2 className="text-3xl font-serif italic text-slate-900 dark:text-white mb-2 leading-tight">
                Partner <span className="not-italic font-sans font-extrabold text-blue-600">Profile.</span>
              </h2>
              <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.3em] flex items-center justify-center md:justify-start">
                {isClientAuthenticated ? (
                  <>
                    <span className="w-2 h-2 rounded-full bg-emerald-500 mr-2 animate-pulse"></span>
                    Verified Identity • ID: {formData.email?.split('@')[0] || 'Member'}
                  </>
                ) : (
                  <>
                    <span className="w-2 h-2 rounded-full bg-slate-300 mr-2"></span>
                    Guest Mode • Sign in to Edit
                  </>
                )}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest font-black text-slate-400 dark:text-slate-600 ml-1">Full Legal Name</label>
                <input 
                  type="text" 
                  value={formData.name}
                  disabled={!isClientAuthenticated}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-white/5 rounded-2xl px-6 py-5 md:py-6 focus:outline-none focus:border-blue-500 transition-all font-bold text-slate-900 dark:text-white text-base shadow-sm disabled:opacity-50 disabled:cursor-not-allowed" 
                  placeholder="e.g. Alexander Vance"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest font-black text-slate-400 dark:text-slate-600 ml-1">Work Email</label>
                <input 
                  type="email" 
                  value={formData.email}
                  disabled={!isClientAuthenticated}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-white/5 rounded-2xl px-6 py-5 md:py-6 focus:outline-none focus:border-blue-500 transition-all font-bold text-slate-900 dark:text-white text-base shadow-sm disabled:opacity-50 disabled:cursor-not-allowed" 
                  placeholder="partner@arvex.studio"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest font-black text-slate-400 dark:text-slate-600 ml-1">Phone Protocol</label>
                <input 
                  type="tel" 
                  value={formData.phone}
                  disabled={!isClientAuthenticated}
                  onChange={e => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-white/5 rounded-2xl px-6 py-5 md:py-6 focus:outline-none focus:border-blue-500 transition-all font-bold text-slate-900 dark:text-white text-base shadow-sm disabled:opacity-50 disabled:cursor-not-allowed" 
                  placeholder="Enter phone number"
                />
              </div>
            </div>

            <div className="space-y-2 h-full">
              <label className="text-[10px] uppercase tracking-widest font-black text-slate-400 dark:text-slate-600 ml-1">Strategic Bio</label>
              <textarea 
                value={formData.bio}
                disabled={!isClientAuthenticated}
                onChange={e => setFormData({ ...formData, bio: e.target.value })}
                className="w-full h-full min-h-[160px] md:min-h-0 bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-white/5 rounded-3xl px-6 py-5 md:py-6 focus:outline-none focus:border-blue-500 transition-all font-bold text-slate-900 dark:text-white text-base resize-none leading-relaxed shadow-sm disabled:opacity-50 disabled:cursor-not-allowed" 
                placeholder="Share your technical expertise or role in the studio's ecosystem..."
              />
            </div>
          </div>

          <div className="mt-12 flex flex-col md:flex-row items-center gap-6">
            {isClientAuthenticated ? (
              <>
                <button 
                  type="submit"
                  disabled={isSaving || saveSuccess}
                  className={`w-full md:w-auto px-12 py-6 rounded-2xl font-black uppercase tracking-widest text-[11px] transition-all shadow-xl active:scale-[0.98] disabled:opacity-50 ${saveSuccess ? 'bg-emerald-600 text-white' : 'bg-blue-600 text-white hover:bg-blue-700 shadow-blue-500/20'}`}
                >
                  {isSaving ? 'Syncing...' : saveSuccess ? 'Changes Applied ✓' : 'Save Changes'}
                </button>
                <button 
                  type="button"
                  onClick={handleSignOut}
                  className="text-[10px] font-black text-rose-500 uppercase tracking-widest hover:text-rose-600 transition-colors"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <div className="flex flex-col md:flex-row items-center gap-4 bg-blue-50 dark:bg-blue-500/5 p-6 rounded-3xl w-full border border-blue-100 dark:border-blue-500/10">
                 <svg className="w-8 h-8 text-blue-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                 </svg>
                 <p className="text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-400 leading-relaxed text-center md:text-left">
                  Modification of partner assets is restricted to <br className="hidden md:block" />
                  <span className="text-blue-600">verified Arvex Studio accounts.</span>
                </p>
              </div>
            )}
          </div>
        </form>

        <div className="bg-slate-50 dark:bg-slate-950 px-8 py-6 text-center border-t border-slate-100 dark:border-white/5">
           <p className="text-[9px] font-bold uppercase tracking-widest text-slate-400 dark:text-slate-600 leading-none">
             Partner identities and bio-assets are encrypted using the Arvex Security Core
           </p>
        </div>
      </div>
    </div>
  );
};

export default ProfileSettings;
