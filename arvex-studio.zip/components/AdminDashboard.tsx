
import React, { useState, useEffect } from 'react';
import { Inquiry } from '../types';

interface AdminDashboardProps {
  onBack: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ onBack }) => {
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);

  useEffect(() => {
    const data = JSON.parse(localStorage.getItem('arvex_inquiries') || '[]');
    setInquiries(data);
  }, []);

  const updateStatus = (id: string, newStatus: Inquiry['status']) => {
    const updated = inquiries.map(iq => iq.id === id ? { ...iq, status: newStatus } : iq);
    setInquiries(updated);
    localStorage.setItem('arvex_inquiries', JSON.stringify(updated));
  };

  const deleteInquiry = (id: string) => {
    if (!window.confirm('Archive this lead permanently?')) return;
    const updated = inquiries.filter(iq => iq.id !== id);
    setInquiries(updated);
    localStorage.setItem('arvex_inquiries', JSON.stringify(updated));
  };

  const getStatusColor = (status: Inquiry['status']) => {
    switch(status) {
      case 'new': return 'bg-blue-500';
      case 'contacted': return 'bg-yellow-500';
      case 'completed': return 'bg-emerald-500';
      default: return 'bg-slate-500';
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans p-6 md:p-12 selection:bg-blue-500/30">
      <div className="max-w-7xl mx-auto">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-16 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <span className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></span>
              <span className="text-[10px] font-black uppercase tracking-[0.4em] text-blue-400">Lead Intelligence Hub</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-serif italic">Inquiry Manager.</h1>
          </div>
          
          <button 
            onClick={onBack}
            className="px-8 py-4 bg-white/5 border border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-white/10 transition-all"
          >
            Exit Studio Dashboard
          </button>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mb-12">
           {[
             { label: 'Total Leads', val: inquiries.length },
             { label: 'New Requests', val: inquiries.filter(i => i.status === 'new').length },
             { label: 'In Progress', val: inquiries.filter(i => i.status === 'contacted').length },
             { label: 'Closed Deals', val: inquiries.filter(i => i.status === 'completed').length },
           ].map((stat, i) => (
             <div key={i} className="bg-white/5 border border-white/10 p-8 rounded-3xl">
                <div className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">{stat.label}</div>
                <div className="text-4xl font-extrabold">{stat.val}</div>
             </div>
           ))}
        </div>

        <div className="overflow-hidden rounded-[40px] border border-white/5 bg-white/[0.02] backdrop-blur-xl">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/5 bg-white/5">
                <th className="p-6 md:p-8 text-[10px] font-black uppercase tracking-widest text-slate-400">Client Identity</th>
                <th className="p-6 md:p-8 text-[10px] font-black uppercase tracking-widest text-slate-400">Narrative</th>
                <th className="p-6 md:p-8 text-[10px] font-black uppercase tracking-widest text-slate-400">Status</th>
                <th className="p-6 md:p-8 text-[10px] font-black uppercase tracking-widest text-slate-400">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {inquiries.length === 0 ? (
                <tr>
                  <td colSpan={4} className="p-20 text-center text-slate-500 italic">
                    No active inquiries detected in the system core.
                  </td>
                </tr>
              ) : inquiries.map((iq) => (
                <tr key={iq.id} className="group hover:bg-white/5 transition-colors">
                  <td className="p-6 md:p-8">
                    <div className="font-bold text-lg mb-1">{iq.name}</div>
                    <div className="text-xs text-blue-400 font-medium">{iq.email}</div>
                    <div className="text-[10px] text-slate-600 mt-2 uppercase tracking-tighter">
                      {new Date(iq.timestamp).toLocaleString()}
                    </div>
                  </td>
                  <td className="p-6 md:p-8 max-w-md">
                    <p className="text-sm text-slate-400 line-clamp-3 leading-relaxed font-light italic">
                      "{iq.message}"
                    </p>
                  </td>
                  <td className="p-6 md:p-8">
                    <select 
                      value={iq.status}
                      onChange={(e) => updateStatus(iq.id, e.target.value as Inquiry['status'])}
                      className={`text-[10px] font-black uppercase tracking-widest px-4 py-2 rounded-full bg-slate-800 border-none focus:ring-2 focus:ring-blue-500 outline-none cursor-pointer ${getStatusColor(iq.status)} text-white`}
                    >
                      <option value="new">New Lead</option>
                      <option value="contacted">Contacted</option>
                      <option value="completed">Project Started</option>
                    </select>
                  </td>
                  <td className="p-6 md:p-8">
                    <div className="flex space-x-4 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button 
                        onClick={() => window.open(`mailto:${iq.email}?subject=Project Consultation - Arvex Studio`)}
                        className="text-xs font-bold text-blue-400 hover:text-white underline tracking-widest uppercase"
                      >
                        Respond
                      </button>
                      <button 
                        onClick={() => deleteInquiry(iq.id)}
                        className="text-xs font-bold text-rose-500 hover:text-white tracking-widest uppercase"
                      >
                        Archive
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
